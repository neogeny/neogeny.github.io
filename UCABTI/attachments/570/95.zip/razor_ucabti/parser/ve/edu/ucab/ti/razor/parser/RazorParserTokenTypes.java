// $ANTLR : "razor.g" -> "RazorParser.java"$

package ve.edu.ucab.ti.razor.parser;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public interface RazorParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int WS = 4;
	int LETTER = 5;
	int DIGIT = 6;
}
