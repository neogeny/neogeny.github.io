// $ANTLR : "razor.g" -> "RazorParser.java"$

package ve.edu.ucab.ti.razor.parser;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;

public class RazorParser extends antlr.LLkParser       implements RazorParserTokenTypes
 {

	public static void parse(String fileName)
			throws FileNotFoundException, RecognitionException,
			TokenStreamException {
		parse(new FileInputStream(fileName));

	}

	public static void parse(InputStream stream)
			throws RecognitionException, TokenStreamException {
		RazorLexer lexer = new RazorLexer(stream);
		RazorParser parser = new RazorParser(lexer);
		parser.program();

	}

protected RazorParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public RazorParser(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected RazorParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public RazorParser(TokenStream lexer) {
  this(lexer,1);
}

public RazorParser(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
}

	public final void program() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(Token.EOF_TYPE);
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"WS",
		"LETTER",
		"DIGIT"
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	
	}
