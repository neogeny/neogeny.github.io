/*
 * Universidad Cat�lica Andr�s Bello
 * Facultad de Ingenier�a
 * Escuela de Ingenier�a Inform�tica
 * 
 * Traductores e Int�rpretes
 * Semestre 2007-21
 * 
 * Proyecto: Wikilator
 * 
 * Integrantes:
 * 
 * 
 * 
 */
package ve.edu.ucab.ti.razor;

import java.io.FileNotFoundException;

import ve.edu.ucab.ti.razor.parser.RazorParser;

import antlr.RecognitionException;
import antlr.TokenStreamException;

public class Main
{

    public static void main(String[] args) throws FileNotFoundException,
            RecognitionException, TokenStreamException
    {
        // TODO: verificar haya por lo menos un argumento
        for (String fileName : args)
            RazorParser.parse(fileName);
    }

}
