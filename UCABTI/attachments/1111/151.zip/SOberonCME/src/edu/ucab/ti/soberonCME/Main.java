/*
 * Universidad Cat�lica Andr�s Bello
 * Facultad de Ingenier�a
 * Escuela de Ingenier�a Inform�tica
 * Traductores e Int�rpretes
 *
 * Proyecto: OficinaSMS
 * 
 * Integrantes:
 * Sergio Meneses
 * Reynaldo Rojas
 * Alejandro Gutierrez
 * Manuel Vargas
 */
package edu.ucab.ti.soberonCME;

import java.io.*;
import java.*;
import edu.ucab.ti.soberonCME.parser.SoberonCMELexer;
import edu.ucab.ti.soberonCME.parser.SoberonCMEParser;

import antlr.*;
import antlr.RecognitionException;
import antlr.TokenStreamException;

public class Main
{
	public static void main(String[] args) throws FileNotFoundException,
	RecognitionException, TokenStreamException
	{
		// TODO: verificar haya por lo menos un argumento
		// TODO: Instanciar analizador l�xico
		// TODO: Instanciar analizador sint�ctico
		// TODO: Manejar excepciones
		for (String fileName : args)
			SoberonCMEParser.parse(fileName);
	}
}
